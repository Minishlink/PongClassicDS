// Includes
#include <PA9.h>       // Include for PA_Lib
#include "jeux.h"
#include "ia.h"
#include "scores.h"

#include "MusicPong02.h"


void unJoueur(void)
{
    PA_Init2D();
    PA_Init16cBg(1, 2);
    PA_Init16cBg(0, 2);
    PA_InitRand();

    PA_LoadTiledBg(1, 3, terrainBG);
    PA_LoadTiledBg(0, 3, unJoueurBG);

    s32 raquette1y = 80, raquette2y = 80, ballex = 124, balley = 96;
    bool versLaDroite = PA_RandMinMax(0, 1);
	bool versLeBas = PA_RandMinMax(0, 1);
	bool pause = 1;
	u8 IAmode = DEF_NORMAL;

	scoreJ1 = 0;
	scoreJ2 = 0;

    PA_LoadSpritePal(1, 0, (void*)balle_Pal);
	PA_CreateSprite(1, 0, (void*)balle_Sprite, OBJ_SIZE_8X8, 1, 0, ballex, balley);

    PA_LoadSpritePal(1, 1, (void*)raquette_Pal);
	PA_CreateSprite(1, 1, (void*)raquette_Sprite, OBJ_SIZE_8X32, 1, 1, 10, raquette1y);
	PA_CreateSprite(1, 2, (void*)raquette_Sprite, OBJ_SIZE_8X32, 1, 1, 237, raquette2y);

	PA_PlayMod(MusicPong02);

    chargerHScores();

	while(1)
	{
		if(Pad.Newpress.Start) choixNbJoueurs();
        if(Pad.Newpress.Select) { if(!pause) pause = 1; else pause = 0; }

		if(!pause)
		{
			if(raquette1y == 144) raquette1y -= Pad.Held.Up * DEF_SPEED_RAQUETTE;
			else if (raquette1y == 16) raquette1y += Pad.Held.Down * DEF_SPEED_RAQUETTE;
			else raquette1y += (Pad.Held.Down - Pad.Held.Up) * DEF_SPEED_RAQUETTE;

			if(versLaDroite) { ballex += DEF_SPEED_BALLE; }
			else { ballex -= DEF_SPEED_BALLE; }
			if(versLeBas) { balley += DEF_SPEED_BALLE; }
			else { balley -= DEF_SPEED_BALLE; }

            raquette2y = f_ia(IAmode, raquette2y, balley); //IA

            testCollisions(ballex, balley, raquette1y, raquette2y, &versLaDroite, &versLeBas);

			//On replace les sprites
			PA_SetSpriteXY(1, 0, ballex, balley);
			PA_SetSpriteXY(1, 1, 10, raquette1y);
			PA_SetSpriteXY(1, 2, 237, raquette2y);

			if((IAmode != DEF_ARCADE) && (IAmode < DEF_AVENTURE))
			{
                //Gestion des Scores
                if(ballex <= -3)
                {
                    scoreJ2++;
                    replacerSprites(&balley, &ballex, &raquette1y, &raquette2y, &versLaDroite, IAmode);
                    IAmode = attendre(IAmode);
                }
                else if(ballex >= 250)
                {
                    scoreJ1++;
                    replacerSprites(&balley, &ballex, &raquette1y, &raquette2y, &versLaDroite, IAmode);
                    IAmode = attendre(IAmode);
                }
			}
			else if (IAmode == DEF_ARCADE)
			{
			    if(ballex <= -3)
			    {
			        chargerHScores();
			        sauverHScores();
			        chargerHScores();
			        PA_16cText(1, 140, 55, 255, 192, "FINISH", 1, 3, 14);
                    PA_16cText(1, 57, 55, 255, 192, "FINISH", 1, 3, 14);
                    replacerSprites(&balley, &ballex, &raquette1y, &raquette2y, &versLaDroite, IAmode);
                    IAmode = attendre(IAmode);
                    scoreJ1 = 0;
                    scoreJ2 = 0;
			    }

			    if((ballex >= 229 && ballex <= 245) && (balley <= raquette2y + 32) && (balley >= raquette2y)) { scoreJ1++; }
                if((ballex <= 18) && (ballex >= 10) && (balley <= raquette1y + 32) && (balley >= raquette1y)) { scoreJ1++; }
                scoreJ2++;

                afficherHScores();
			}
			else if (IAmode >= DEF_AVENTURE)
			{
			    //Gestion des Scores
                if(ballex <= -3)
                {
                    scoreJ2++;
                    replacerSprites(&balley, &ballex, &raquette1y, &raquette2y, &versLaDroite, IAmode);
                    IAmode = attendre(IAmode);
                }
                else if(ballex >= 250)
                {
                    IAmode = modeAventure(IAmode);
                    replacerSprites(&balley, &ballex, &raquette1y, &raquette2y, &versLaDroite, IAmode);
                    IAmode = attendre(IAmode);
                }
			}

        }

		else if(pause)
		{
            IAmode = changerIAmode(IAmode, 0);
		}

        afficherIAmode(IAmode);

		afficherScore();

		PA_WaitForVBL();
		PA_16cErase(1);
		PA_16cErase(0);
	}
}


