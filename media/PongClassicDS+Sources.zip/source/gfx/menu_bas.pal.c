//Palette created using Mollusk's PAGfxConverter

const unsigned short menu_bas_Pal[14] __attribute__ ((aligned (4))) = {
64543, 32768, 49680, 55029, 43370, 65535, 65402, 43237, 53908, 32869, 64511, 43242, 58232, 54901};
