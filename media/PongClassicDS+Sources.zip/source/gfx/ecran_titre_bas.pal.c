//Palette created using Mollusk's PAGfxConverter

const unsigned short ecran_titre_bas_Pal[14] __attribute__ ((aligned (4))) = {
64543, 32768, 43242, 65535, 49680, 55029, 43370, 43237, 64511, 53908, 32869, 54901, 65402, 58232};
