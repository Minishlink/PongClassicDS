//Palette created using Mollusk's PAGfxConverter

const unsigned short demoBG_Pal[14] __attribute__ ((aligned (4))) = {
64543, 32768, 43242, 43237, 32869, 49680, 65535, 55029, 58232, 43370, 64511, 54901, 65402, 53908};
