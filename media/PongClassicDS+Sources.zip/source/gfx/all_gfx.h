//Gfx converted using Mollusk's PAGfx Converter

//This file contains all the .h, for easier inclusion in a project

#ifndef ALL_GFX_H
#define ALL_GFX_H

#ifndef PAGfx_struct
    typedef struct{
    void *Map;
    int MapSize;
    void *Tiles;
    int TileSize;
    void *Palette;
    int *Info;
} PAGfx_struct;
#endif


// Sprite files : 
extern const unsigned char balle_Sprite[64] __attribute__ ((aligned (4))) ;  // Pal : balle_Pal
extern const unsigned char raquette_Sprite[256] __attribute__ ((aligned (4))) ;  // Pal : raquette_Pal

// Background files : 
extern const int demoBG_Info[3]; // BgMode, Width, Height
extern const unsigned short demoBG_Map[768] __attribute__ ((aligned (4))) ;  // Pal : demoBG_Pal
extern const unsigned char demoBG_Tiles[8640] __attribute__ ((aligned (4))) ;  // Pal : demoBG_Pal
extern PAGfx_struct demoBG; // background pointer

extern const int deuxJoueursBG_Info[3]; // BgMode, Width, Height
extern const unsigned short deuxJoueursBG_Map[768] __attribute__ ((aligned (4))) ;  // Pal : deuxJoueursBG_Pal
extern const unsigned char deuxJoueursBG_Tiles[7872] __attribute__ ((aligned (4))) ;  // Pal : deuxJoueursBG_Pal
extern PAGfx_struct deuxJoueursBG; // background pointer

extern const int ecran_titre_bas_Info[3]; // BgMode, Width, Height
extern const unsigned short ecran_titre_bas_Map[768] __attribute__ ((aligned (4))) ;  // Pal : ecran_titre_bas_Pal
extern const unsigned char ecran_titre_bas_Tiles[10816] __attribute__ ((aligned (4))) ;  // Pal : ecran_titre_bas_Pal
extern PAGfx_struct ecran_titre_bas; // background pointer

extern const int ecran_titre_haut_Info[3]; // BgMode, Width, Height
extern const unsigned short ecran_titre_haut_Map[768] __attribute__ ((aligned (4))) ;  // Pal : ecran_titre_haut_Pal
extern const unsigned char ecran_titre_haut_Tiles[13632] __attribute__ ((aligned (4))) ;  // Pal : ecran_titre_haut_Pal
extern PAGfx_struct ecran_titre_haut; // background pointer

extern const int menu_bas_Info[3]; // BgMode, Width, Height
extern const unsigned short menu_bas_Map[768] __attribute__ ((aligned (4))) ;  // Pal : menu_bas_Pal
extern const unsigned char menu_bas_Tiles[14912] __attribute__ ((aligned (4))) ;  // Pal : menu_bas_Pal
extern PAGfx_struct menu_bas; // background pointer

extern const int menu_haut_Info[3]; // BgMode, Width, Height
extern const unsigned short menu_haut_Map[768] __attribute__ ((aligned (4))) ;  // Pal : menu_haut_Pal
extern const unsigned char menu_haut_Tiles[19328] __attribute__ ((aligned (4))) ;  // Pal : menu_haut_Pal
extern PAGfx_struct menu_haut; // background pointer

extern const int terrainBG_Info[3]; // BgMode, Width, Height
extern const unsigned short terrainBG_Map[768] __attribute__ ((aligned (4))) ;  // Pal : terrainBG_Pal
extern const unsigned char terrainBG_Tiles[1984] __attribute__ ((aligned (4))) ;  // Pal : terrainBG_Pal
extern PAGfx_struct terrainBG; // background pointer

extern const int unJoueurBG_Info[3]; // BgMode, Width, Height
extern const unsigned short unJoueurBG_Map[768] __attribute__ ((aligned (4))) ;  // Pal : unJoueurBG_Pal
extern const unsigned char unJoueurBG_Tiles[6912] __attribute__ ((aligned (4))) ;  // Pal : unJoueurBG_Pal
extern PAGfx_struct unJoueurBG; // background pointer


// Palette files : 
extern const unsigned short balle_Pal[2] __attribute__ ((aligned (4))) ;
extern const unsigned short raquette_Pal[2] __attribute__ ((aligned (4))) ;
extern const unsigned short demoBG_Pal[14] __attribute__ ((aligned (4))) ;
extern const unsigned short deuxJoueursBG_Pal[14] __attribute__ ((aligned (4))) ;
extern const unsigned short ecran_titre_bas_Pal[14] __attribute__ ((aligned (4))) ;
extern const unsigned short ecran_titre_haut_Pal[33] __attribute__ ((aligned (4))) ;
extern const unsigned short menu_bas_Pal[14] __attribute__ ((aligned (4))) ;
extern const unsigned short menu_haut_Pal[33] __attribute__ ((aligned (4))) ;
extern const unsigned short terrainBG_Pal[14] __attribute__ ((aligned (4))) ;
extern const unsigned short unJoueurBG_Pal[14] __attribute__ ((aligned (4))) ;


#endif

