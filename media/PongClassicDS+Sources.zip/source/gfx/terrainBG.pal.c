//Palette created using Mollusk's PAGfxConverter

const unsigned short terrainBG_Pal[14] __attribute__ ((aligned (4))) = {
64543, 32768, 32869, 43242, 49680, 43237, 43370, 55029, 58232, 54901, 65535, 65402, 53908, 64511};
