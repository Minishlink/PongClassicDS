//Palette created using Mollusk's PAGfxConverter

const unsigned short unJoueurBG_Pal[14] __attribute__ ((aligned (4))) = {
64543, 32768, 43242, 43237, 43370, 49680, 32869, 65402, 54901, 53908, 55029, 65535, 58232, 64511};
