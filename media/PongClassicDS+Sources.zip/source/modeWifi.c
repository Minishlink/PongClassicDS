// Includes
#include <PA9.h>       // Include for PA_Lib
#include "jeux.h"

#include "MusicPong01.h"

//##################################################################################################
//#-------------------------------------- WIFI MODE -----------------------------------------------#
//##################################################################################################

void wifiPlay(void)
{
   PA_Init2D();

    PA_InitText(1, 0);
	PA_OutputSimpleText(1, 0, 0,"Sorry, not available :(");
	PA_OutputSimpleText(1, 0, 2,"Press START to continue...");

    PA_PlayMod(MusicPong01);

	while(1)
	{
        if(Pad.Newpress.Start) choixNbJoueurs();

		PA_WaitForVBL();
	}
}


