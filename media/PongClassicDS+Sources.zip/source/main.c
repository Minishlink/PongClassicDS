// Includes
#include <PA9.h>       // Include for PA_Lib
#include "gfx/all_gfx.c"
#include "main.h"

#include "MusicPong01.h"

//function : main()
int main(int argc, char ** argv)
{
	PA_Init();    // Initializes PA_Lib
	PA_InitVBL(); // Initializes a standard VBL
	PA_InitRand();
	PA_InitSound();

	bool bfatok = fatInitDefault();    // seule fonction de la libfat directement appellée

    if(!bfatok)
    {
        while(1)
        {
            PA_InitText(1, 2);

            PA_OutputSimpleText(1, 0, 8, "LIB FAT ECHEC : CONTACT MINISHLINK ! TURN OFF YOUR NDS !");
            PA_WaitForVBL();
        }
    }
    else { ecranTitre(); }

    //ecranTitre();

	return 0;
} // End of main()


void ecranTitre(void)
{
    PA_Init2D();

    PA_LoadTiledBg(1, 3, ecran_titre_haut);
	PA_LoadTiledBg(0, 3, ecran_titre_bas);

	PA_PlayMod(MusicPong01);

	while (1)
	{
        if(Pad.Newpress.A) choixNbJoueurs();

		PA_WaitForVBL();
	}
}


void choixNbJoueurs(void)
{
	PA_Init2D();

	PA_LoadTiledBg(1, 3, menu_haut);
	PA_LoadTiledBg(0, 3, menu_bas);

	PA_PlayMod(MusicPong01);

	while(1)
	{
        if(Pad.Newpress.X && !Pad.Held.A) unJoueur();
		else if(Pad.Newpress.Y) deuxJoueurs();
		else if(Pad.Held.A && Pad.Held.X) wifiPlay();
		else if(PA_StylusInZone(0, 178, 176, 192)) demo();
		else if(Pad.Newpress.B) ecranTitre();


		PA_WaitForVBL();
	}
}



